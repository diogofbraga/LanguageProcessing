Nesta pasta residem os ficheiros que são os filtros criados com a extensão .awk:
	- a.awk é o filtro correspondente à alínea a)
	- b.awk é o filtro correspondente à alínea b)
	- c.awk é o filtro correspondente à alínea c)
	- d.awk é o filtro correspondente à alínea d)
	- Filtro.awk é o filtro que corresponde à resolução de todas as alíneas anteriores e cria o resultado em HTML

Pastas que eventualmente forem criadas correspondem ou ao output do filtro c.awk (C_HTML), ou ao output do filtro Filtro.awk (RESULTADOS_HTML)
